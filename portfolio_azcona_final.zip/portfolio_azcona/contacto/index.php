<?php
include("../../conexion/index.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];

    $sql = "INSERT INTO usuarios (nombre, correo) VALUES ('$nombre', '$correo')";

    if ($conn->query($sql) === TRUE) {
        echo "Nuevo registro creado exitosamente";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/miestilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="icon" href="logo.jpg">
    <title>Insertar Datos</title>
</head>
<body background="../images/fondo.png">
<div class="contenedor-header">
        <header>
            <div class="logo">
                <a href="../index.php">
                    <img src="../images/logo.png" alt="logo" width="130" height="80">
                </a>
            </div>
            <nav id="nav">
                <a href="../index.php">INICIO</a>
                <a href="../ilustraciones/index.php">ILUSTRACIONES</a>
                <a href="../animaciones/index.php">ANIMACIONES</a>
                <a href="../contacto/index.php">CONTACTO</a>
                <a href="../juegos/index.php">JUEGOS</a>
            </nav>
            <div class="nav-responsive">
                <i class="fa-solid fa-bars" id="menu-toggle"></i>
            </div>
        </header>
    </div>
    <br>
    <br>
    <div class="contenido-bannerdos">
        <div class="contenedor-img">
            <img src="../images/caracont.png" alt="cara" width="1290" height="45">
        </div>
    </div>
    <br>
    <br>
    <h1>CONTACTO</h1>
    <br>
    <br>
    <div class="form">    
        <form action="index.php" method="POST">
            <br>
            <label for="nombre">Nombre:</label>
            <input type="text" name="nombre" id="nombre" required>
            <br><br>
            <label for="correo">Correo:</label>
            <input type="email" name="correo" id="correo" required>
            <br><br>
            <button type="submit">Insertar</button>
        </form>
    </div>
    <br>
    <br>
    <br>
    <footer>
        <div class="footer-container">
            <a href="https://www.instagram.com/benjiboy_1001/" class="footer-icon"><i class="fab fa-instagram"></i></a>
            <a href="https://mail.google.com/mail/u/0/?ogbl#inbox" class="footer-icon"><i class="fas fa-envelope"></i></a>
        </div>
    </footer>
   
    <script>
        document.getElementById('menu-toggle').addEventListener('click', function() {
            var nav = document.getElementById('nav');
            nav.classList.toggle('active');
        });
    </script>
    <script src="../js/script.js"></script>
</body>
</html>
