<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/miestilo.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="icon" href="logo.jpg">
    <title>Juegos</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 0;
            padding: 0;
        }
        iframe {
            border: none;
            width: 70%;
            height: 90vh;
        }
        header {
            padding: 1rem;
        }
    </style>
</head>
<body background="../images/fondo.png">
    <div class="contenedor-header">
        <header>
            <div class="logo">
                <a href="../index.php">
                    <img src="../images/logo.png" alt="logo" width="130" height="80">
                </a>
            </div>
            <nav id="nav">
                <a href="../index.php">INICIO</a>
                <a href="../ilustraciones/index.php">ILUSTRACIONES</a>
                <a href="../animaciones/index.php">ANIMACIONES</a>
                <a href="../contacto/index.php">CONTACTO</a>
                <a href="../juegos/index.php">JUEGOS</a>
            </nav>
            <div class="nav-responsive">
                <i class="fa-solid fa-bars" id="menu-toggle"></i>
            </div>
        </header>
    </div>
    
    <br><br>

    <div class="contenido-banner">
        <div class="contenedor-img">
            <img src="../images/carajuego.png" alt="cara" width="1220" height="75">
        </div>
    </div>

    <br><br>

    <h1>JUEGOS</h1>

    <iframe 
        src="https://play.unity.com/en/games/e9653da5-8775-4820-93cd-80e6ad950c50/webgl-builds" 
        title="Juego Unity">
    </iframe>
    <br>
    <h1>¡Prueba nuestro juego de celular!</h1>
    <img src="../images/codigo.png" width="80" height="80">

    <footer>
        <div class="footer-container">
            <a href="https://www.instagram.com/benjiboy_1001/" class="footer-icon"><i class="fab fa-instagram"></i></a>
            <a href="https://mail.google.com/mail/u/0/?ogbl#inbox" class="footer-icon"><i class="fas fa-envelope"></i></a>
        </div>
    </footer>

    <script>
        document.getElementById('menu-toggle').addEventListener('click', function() {
            var nav = document.getElementById('nav');
            nav.classList.toggle('active');
        });
    </script>
</body>
</html>